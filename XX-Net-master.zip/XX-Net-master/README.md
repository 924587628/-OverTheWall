XX-Net
=================
* XX-Net is a free desktop application that delivers fast, reliable and secure access to the open Internet for users in censored regions. It uses google app engine (GAE) as a proxy server through the firewall.


Wiki
-----
* [中文文档](https://github.com/XX-net/XX-Net/wiki/%E4%B8%AD%E6%96%87%E6%96%87%E6%A1%A3)

* [English Home](https://github.com/XX-net/XX-Net/wiki/English-Home-Page)

* [فارسی صفحه اصلی](https://github.com/XX-net/XX-Net/wiki/Persian-home-page)


Downloads
---------
* [__Download page__](https://github.com/XX-net/XX-Net/blob/master/code/default/download.md)


Links
------
* Usage :  https://github.com/XX-net/XX-Net/wiki/How-to-use

* Update :  https://github.com/XX-net/XX-Net/wiki/How-to-update

* Issues :  https://github.com/XX-net/XX-Net/issues?q=sort:updated-desc+is:open


Help
-----
* https://github.com/XX-net/XX-Net/wiki/How-to-contribute
